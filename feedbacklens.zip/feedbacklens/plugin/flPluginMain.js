var hostUrl = 'localhost/myfirstrepo/feedbacklens/public/api/';
var domainId;
var myIp = '';
var opSys  = '';
var browser = '';

window.onload = function() {

	$.get("http://ipinfo.io", function(response) {
    	myIp = response.ip;
	}, "jsonp");

	opSys = navigator.platform;
	browser = navigator.appCodeName;
	getPluginProperties();
}

function loadPlugin(domainIfoJson) {
	

	var pageBody = document.getElementsByTagName('body')[0];
	// Floating button
	var pluginBtn = b();
	pluginBtn.id = 'idPluginBtn';
	pluginBtn.classList.add('flPluginBtn');
	pluginBtn.innerHTML = 'Feedback';
	pageBody.appendChild(pluginBtn);

	// Plugin parent div
	var div1 = d();
	div1.id = 'idFlPluginModal';
	div1.classList.add('flPluginModal');
	
	// Plugin container div
	var div11 =  d();
	div11.classList.add('flPluginModalContent');
	div11.id ='idFlPluginModalContent';
	// Close button
	var spanCloseBtn =  s();
	spanCloseBtn.innerHTML = '&times;';
	spanCloseBtn.id = 'idFlPluginClose';
	spanCloseBtn.classList.add('flPluginClose');

	div11.appendChild(spanCloseBtn);

	// Plugin Header
	var flHeader = h3();
	flHeader.style.textAlign = 'center';
	flHeader.innerHTML = 'Feedback';
	div11.appendChild(flHeader);

	var div111 =  d();
	div111.classList.add('flPluginInputContainer');
	div111.id = 'idFlPluginInputContainer';

	// Rate element
	var rateElement = ul();
	rateElement.classList.add('flRateElement');
	var svgCircle = '';
    for(var i=0; i<5; i++){
        svgCircle = svgCircle.concat('<li><svg height="40" width="40"> <polygon fill="#FFF" points="20,4.061834335327148 24.217514038085938,16.195087432861328 37.06020736694336,16.456802368164062 26.824085235595703,24.217281341552734 30.54378890991211,36.51227951049805 20,29.17526626586914 9.45621109008789,36.51227951049805 13.175914764404297,24.217281341552734 2.939790725708008,16.456802368164062 15.782485961914062,16.195087432861328 20,4.061834335327148 24.217514038085938,16.195087432861328" stroke="#FFD54F" stroke-width="2" stroke-linejoin="round" onclick="setRate(this, '+(i+1)+');" id="idCir'+i+'" class="flCir rateCircles" /></svg></li>');
    }
    rateElement.innerHTML = svgCircle;

	div111.appendChild(rateElement);

	
	// Categories input
	var flCatInput = sl();
	flCatInput.classList.add('flPluginInput');
	flCatInput.id = 'idFlCategory';
	var flEmptyOpt = o();
	flEmptyOpt.value = '';
	flEmptyOpt.innerHTML = 'Select Category *';
	flCatInput.appendChild(flEmptyOpt);
	
	div111.appendChild(flCatInput);

	// Sub Categories input
	var flSubCatInput = sl();
	flSubCatInput.classList.add('flPluginInput');
	flSubCatInput.id = 'idFlSubCategory';
	var flSubCatEmptyOpt = o();
	flSubCatEmptyOpt.value = '';
	flSubCatEmptyOpt.innerHTML = 'Select Sub Category *';
	flSubCatInput.appendChild(flSubCatEmptyOpt);
	div111.appendChild(flSubCatInput);

	// Text area to write us
	var flTextAreaInput = ta();
	flTextAreaInput.classList.add('flPluginInput');
	flTextAreaInput.id = 'idFlComments';
	flTextAreaInput.rows = 4;
	flTextAreaInput.placeholder = 'Write Us *';
	flTextAreaInput.style.resize = 'vertical';
	flTextAreaInput.maxLength = 1000;
	div111.appendChild(flTextAreaInput);

	// Input text for email
	var flTextInputEmail = t();
	flTextInputEmail.classList.add('flPluginInput');
	flTextInputEmail.id = 'idFlEmail';
	flTextInputEmail.type = 'email';
	flTextInputEmail.placeholder = 'Email (Optional)';
	flTextInputEmail.maxLength = 100;
	div111.appendChild(flTextInputEmail);

	// Hidden Input text for rate
	var flTextInputRate = t();
	//flTextInputRate.classList.add('flPluginInput');
	flTextInputRate.type = 'hidden';
	flTextInputRate.id = 'idRate'
	div111.appendChild(flTextInputRate);

	// Submit button
	var flSubmitBtn = t();
	flSubmitBtn.classList.add('flPluginInput', 'flSubmitButton');
	flSubmitBtn.type = 'button';
	flSubmitBtn.value = 'Submit';
	flSubmitBtn.setAttribute( "onClick", "javascript: flSubmitForm();" );
	div111.appendChild(flSubmitBtn);

	
	div11.appendChild(div111);

	// Plugin container div
	var div112 =  d();
	//div112.classList.add('flPluginModalContent');
	div112.id ='idFlPluginThnkDiv';
	div112.style.display = 'none';
	div112.innerHTML = 'Thank you for your valuable feedback';
	div11.appendChild(div112);

	
	div1.appendChild(div11);
	pageBody.appendChild(div1);

	// Binding modal events
	var modal = eId('idFlPluginModal');
	var btn = eId("idPluginBtn");
	var span = eId("idFlPluginClose");
		
	btn.onclick = function() {
		flResetInputs();
		showThankDiv(false);
		modal.style.display = "block";
	}
		
	span.onclick = function() {
		modal.style.display = "none";
	}
		
	window.onclick = function(event) {
		if (event.target == modal) {
		    modal.style.display = "none";
		}
	}

	// Set Categories and subcategories
	setOptionsToCat(domainIfoJson.pluginconfig.cat);
	setOptionsToSubCat(domainIfoJson.pluginconfig.subcat);
}

function setRate(ev, rate) {
    flToggleRateElement(rate, false);
    eId("idRate").value = rate;
}

function flSubmitForm() {
	if(flIsValidaeInputs()) {
		alert("All Valid");
		postFeedback();
	} else {
		alert("Not Valid");
	}
}

function flGetAllInputElements() {
	var inputValues = {
		selectedRate : eId('idRate'),
		selectedCat : eId('idFlCategory'),
		selectedSubCat : eId('idFlSubCategory'),
		email : eId('idFlEmail'),
		comments : eId('idFlComments')
	}

	return inputValues;
}

function flResetInputs() {

	var inputFields = flGetAllInputElements();

	inputFields.selectedRate.value = '',
	inputFields.selectedCat.value = '',
	inputFields.selectedSubCat.value = '',
	inputFields.email.value = '',
	inputFields.comments.value = '';

    // Second parameter of following function is for check if to reset rate elements or set one selected
	flToggleRateElement(0, true);
}


function flIsValidaeInputs() {
	var inputFields = flGetAllInputElements();

	if(flIsEmptyField(inputFields.selectedRate)) {
		return false;
	}

	if(flIsEmptyField(inputFields.selectedCat)) {
		return false;
	}

	if(flIsEmptyField(inputFields.selectedSubCat)) {
		return false;
	}

	if(!flIsEmptyField(inputFields.email)) {
		if(!validateEmail(inputFields.email.value))
			return false;
	}

	if(flIsEmptyField(inputFields.comments)) {
		return false;
	}

	return true;

}

function validateEmail(mail)   
{  
	if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))  
	    return true;
	else
	    return false;
} 

function flIsEmptyField(element) {
	if(element.value == '' || element.value.length == 0)
		return true;
	else
		return false;
}

function flToggleRateElement(rate, isReset) {
	var x = document.getElementsByClassName("rateCircles");
            
    if(isReset){
       		for(var i=0; i<x.length; i++){
       			x[i].classList.remove('flClsBlue');
       		}
       } else {    	
	       for(var i=0; i<x.length; i++) {
	       		if(i < rate)
	            	x[i].classList.add('flClsBlue');
	            else
	            	x[i].classList.remove('flClsBlue');
	       }
       }
}


function getPluginProperties() {
	var domainIfoJson = {};
	var xhr = new XMLHttpRequest();
	var domainName = window.location.hostname;
	domainName = domainName.replace("www.", "");
	var flReqUrl = 'public/api/domain/fetchData?domainName='.concat(domainName);
	xhr.open("GET", flReqUrl, true);
	xhr.onload = function (e) {
	  if (xhr.readyState === 4) {
		    if (xhr.status === 200) {
		      	var domainInfoStr = xhr.responseText;
		      	if(domainInfoStr != null && domainInfoStr != '') {
			      	domainIfoJson = JSON.parse(domainInfoStr);
			      	//console.log(domainIfoJson);
			      	if(domainIfoJson.pluginconfig.properties.ISACTIVE == 1) {
				    	loadPlugin(domainIfoJson);
				    	domainId = domainIfoJson.domain.DOMAIN_ID;
				    	//alert(JSON.stringify(domainIfoJson));   
				    	if(domainIfoJson.pluginconfig.properties.ALIGNMENT.toLowerCase() == 'left')
    						eId('idPluginBtn').classList.add('flPluginBtnPropLeft');
    					else if(domainIfoJson.pluginconfig.properties.ALIGNMENT.toLowerCase() == 'right')
    						eId('idPluginBtn').classList.add('flPluginBtnPropRight');
    					else if(domainIfoJson.pluginconfig.properties.ALIGNMENT.toLowerCase() == 'center')
    						eId('idPluginBtn').classList.add('flPluginBtnPropBottomCenter');

    					eId('idPluginBtn').style.backgroundColor = domainIfoJson.pluginconfig.properties.PLUGIN_COLOR;
	
				  	}
			  	}
		    } else {
		      	console.log(xhr.statusText);
		    }
	  }
	};
	xhr.onerror = function (e) {
	  console.error(xhr.statusText);
	};
	xhr.send(null);

	return domainIfoJson;
}

function setOptionsToCat(categories) {
	var catElement = eId('idFlCategory');
	for(var i=0; i<categories.length; i++) {
		var flCatOpt = o();
		flCatOpt.value = categories[i].CAT_ID;
		flCatOpt.innerHTML = categories[i].CAT_NAME;
		catElement.appendChild(flCatOpt);
	}
}

function setOptionsToSubCat(subCategories) {
	var catElement = eId('idFlSubCategory');
	for(var i=0; i<subCategories.length; i++) {
		var flSubCatOpt = o();
		flSubCatOpt.value = subCategories[i].SUBCAT_ID;
		flSubCatOpt.innerHTML = subCategories[i].SUBCAT_NAME;
		catElement.appendChild(flSubCatOpt);
	}
}

function postFeedback() {
	var http = new XMLHttpRequest();
	var url = "public/api/feedback/sendFeedBack?";
	var params = "";
	var inputFields = flGetAllInputElements();

	var resol=""+$(window).width()+"x"+$(window).height();
	var fulldomain = 'Default';//window.location.href;
	var device = 'default';
	var country = 'default';

	params = params.concat('domainId='+domainId+'&'+'&');
	params = params.concat('catId='+inputFields.selectedCat.value+'&');
	params = params.concat('subcatId='+inputFields.selectedSubCat.value+'&');    
	params = params.concat('url='+fulldomain+'&');
	params = params.concat('rating='+inputFields.selectedRate.value+'&');
	params = params.concat('text='+inputFields.comments.value+'&');
	params = params.concat('os='+opSys+'&');
	params = params.concat('resolution='+resol+'&');
	params = params.concat('device='+device+'&');
	params = params.concat('ip='+myIp+'&');
	params = params.concat('browser='+browser+'&');
	params = params.concat('country='+country+'&');
	params = params.concat('email='+inputFields.email.value);

	http.open("POST", url, true);

	//Send the proper header information along with the request
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	http.onreadystatechange = function() {//Call a function when the state changes.
	    if(http.readyState == 4 && http.status == 200) {
	        //fade(eId('idFlPluginModal'));
	        showThankDiv(true);
	    }
	}
	http.send(params);
}

function showThankDiv(display) {
	eId('idFlPluginInputContainer').style.display = display ? 'none' : 'block';
	eId('idFlPluginThnkDiv').style.display =  display ? 'block' : 'none';
}

function b() {
	return document.createElement("BUTTON");
}

function d() {
	return document.createElement("DIV");
}

function s() {
	return document.createElement("SPAN");
}

function sl() {
	return document.createElement("SELECT");
}

function o() {
	return document.createElement("OPTION");
}

function h3() {
	return document.createElement("H3");
}

function ul() {
	return document.createElement("UL");
}

function ta() {
	return document.createElement("TEXTAREA");
}

function t() {
	return document.createElement("INPUT");
}

function eId(eId) {
	return document.getElementById(eId);
}

function fade(element) {
    var op = 1;  // initial opacity
    var timer = setInterval(function () {
        if (op <= 0.1){
            clearInterval(timer);
            element.style.display = 'none';
        }
        element.style.opacity = op;
        element.style.filter = 'alpha(opacity=' + op * 100 + ")";
        op -= op * 0.1;
    }, 50);
}
